const showBtn = document.getElementById("showBtn");
const ProductList = document.getElementById("Product List");

// 1. Array มี 4 รายการ
// 2. แต่ละรายการเป็น Object
// 3. แต่ละ Object มีอย่างน้อย 3 fields (name, price, category)
const products = [
    { name: "Wireless Keyboard", price: "1,590 บาท", category: "อุปกรณ์ไอที" },
    { name: "Ergonomic Mouse", price: "890 บาท", category: "อุปกรณ์ไอที" },
    { name: "Gaming Headset", price: "2,490 บาท", category: "เครื่องเสียง" },
    { name: "Mechanical Numpad", price: "790 บาท", category: "อุปกรณ์ไอที" },
];

let isShow = false;

// ถ้าคลิกปุ่ม ให้ตัดสินใจแสดง/ซ่อน card (Very simple: if click then show the card)
showBtn.addEventListener("click", function () {
    if (isShow === false) {
        // วนลูป forEach เพื่อสร้างและแสดง card
        products.forEach(function (product) {
            const productCard = document.createElement("article");
            productCard.classList.add("product-card");

            productCard.innerHTML = `
                <h3>${product.name}</h3>
                <p><strong>ราคา:</strong> ${product.price}</p>
                <p><strong>หมวดหมู่:</strong> ${product.category}</p>
            `;

            ProductList.appendChild(productCard);
        });

        // เปลี่ยนข้อความปุ่ม และเปลี่ยนสถานะ
        showBtn.textContent = "ซ่อนสินค้า";
        isShow = true;
    } else {
        // ล้างการ์ดออกไปเมื่อกดอีกครั้ง
        ProductList.innerHTML = "";
        showBtn.textContent = "ดูสินค้า";
        isShow = false;
    }
});